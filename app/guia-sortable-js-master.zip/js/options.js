const profesorado = document.getElementById('profesorado');
const tareasCompletadas = document.getElementById('tareasCompletadas');
function pintaProfe(e) {
	horasProfe = e.getAttribute("horas");
	nombreProfe = e.getAttribute("nombre");
	if (horasProfe < 20) {
		color = "red";
	} else {
		color = "green";
	}
	estilo = " style='color:" + color + "'";
	e.innerHTML = nombreProfe + "<span" + estilo + ">" + " ( " + horasProfe + " h)" + "</span>";
}


function pintaModulo(e) {
	horasModulo = e.getAttribute("horas");

	nombre = e.getAttribute("nombre");
	//ciclo = e.getAttribute("ciclo");
	tipo = e.getAttribute("tipo");
	cadenaProfe = "";
	if (e.getAttribute("profe") != null) {
		nombreProfe = e.getAttribute("profe");
		cadenaProfe = "->" + nombreProfe;
	} 
	e.innerHTML = "<i class='fas fa-grip-lines mr-2'></i>"+ nombre + "(" + horasModulo + "h) " + tipo + cadenaProfe;
}

function reiniciaModulo(e){
	e.classList.toggle('titulo');
	e.removeAttribute('clonado');
	e.removeAttribute('profe'); //ya no está asociado a ningún profe
	e.style.color = "black";
	e.style.opacity = 1;
	pintaModulo(e);

}

const listaProfesorado = Sortable.create(profesorado, {
	group: {
		name: "lista-tareas",
		pull: true,
		
		put: true
	},
	animation: 150,
	easing: "cubic-bezier(0.895, 0.03, 0.685, 0.22)",
	handle: ".fas",
	filter: ".titulo",
	// ghostClass: "active",
	chosenClass: "active",
	//dragClass: "invisible"
	dataIdAttr: "data-identificador",
	sort: false,
	/* onChoose: (evento) => {
		console.log('Se ha seleccionado un elemento')},
	onUnchoose: (evento) => { console.log('Se ha deseleccionado un elemento') },
	onStart: (evento) => { console.log('Se inicio el drag and drop') },
	
	onEnd: (evento) => { console.log('On End') },

	*/
	
	onAdd: (evt) => { //AGREGO UN ELEMENTO A LA LISTA DE PROFES
		elementoAdd = evt.item;
		//le pongo el nombre del ciclo al final del nombre
		let ciclo = elementoAdd.getAttribute("ciclo");
		elementoAdd.innerHTML = elementoAdd.innerHTML + "["+ciclo+"]";
		let horasAdd = elementoAdd.getAttribute('horas'); //averiguo las horas del elemento añadido
		let idAdd = elementoAdd.getAttribute('id'); //averiguo el id del elemento añadido
		let padre = elementoAdd.parentElement;
		//no se puede poner el primero para eso averguo en que posición está
		esPrimero=false;
		for (i = 0; i < padre.children.length; i++){
			let hijo = padre.children[i];
			let idHijo = hijo.getAttribute('id');
			if (idHijo == idAdd && i==0 ) {
				console.log( "indice: "+ i);
				elementoAdd.parentNode.removeChild(elementoAdd); //borro el elemento si lo ha colocado al principio
				esPrimero=true;
				let elementoClonado = document.querySelector("div[clonado='" + idHijo + "'");
				reiniciaModulo(elementoClonado);
			}
		}
		if (!esPrimero) {
			encontrado = false;
			for (i = padre.children.length - 1; i >= 0; i--) { //recorro los elementos hijo del último al primero
				let hijo = padre.children[i];
				let idHijo = hijo.getAttribute('id');
				if ( idHijo == idAdd ) {
					encontrado = true;
				}
				//console.log(hijo);
				if (hijo.classList.contains("titulo") && encontrado) { //SI ES PROFESOR
					let horasProfe = 0;
					if (hijo.getAttribute("horas")) {
						horasProfe = hijo.getAttribute("horas");
					}
					horasProfe = parseInt(horasProfe) + parseInt(horasAdd);

					hijo.setAttribute("horas", horasProfe); //guarda en el atributo el número de horas
					nombreProfe = hijo.getAttribute("nombre");
					
					pintaProfe(hijo);
					//ahora pone el nombre del profe en la lista de la derecha
					let elementoClonado = document.querySelector("div[clonado='" + idAdd + "'");

					//elementoClonado.innerHTML = elementoClonado.innerHTML + "->" + nombreProfe;
					elementoClonado.setAttribute("profe", nombreProfe);
					pintaModulo(elementoClonado);
					break;
				} else { //SI ES UN MÓDULO 

				}
				horas = hijo.getAttribute('horas');
			}
		}
	},

	onRemove: (evt) => {
		

	 },
		/*
	onUpdate: (evento) => { console.log('Se actualizo la lista') },
	onFilter: (evento) => { console.log('Se intento mover un elemento filtrado') },
	onMove: (evento) => { console.log('Se movio un elemento') }, 
	onChange: (evt) => {
		console.log('CHANGE')
	},
/*	store: {
		set: function(sortable){
			const orden = sortable.toArray();
			localStorage.setItem('lista-tareas', orden.join('|'));
		},

		get: function(){
			const orden = localStorage.getItem('lista-tareas');
			return orden ? orden.split('|') : [];
		}
	},*/

	 /* onChoose: (evento) => { 
	 	console.log('Se ha seleccionado un elemento')
	 },
	 onUnchoose: (evento) => { console.log('Se ha deseleccionado un elemento') },
	 onStart: (evento) => { console.log('Se inicio el drag and drop') },
	 onEnd: (evento) => { console.log('On End') },
	 onAdd: (evento) => { console.log('Se agrego un elemento a la lista') },
	 onRemove: (evento) => { console.log('Se elimino un elemento a la lista') },
	 onUpdate: (evento) => { console.log('Se actualizo la lista') },
	 onFilter: (evento) => { console.log('Se intento mover un elemento filtrado') },
	 onMove: (evento) => { console.log('Se movio un elemento') },
	 onChange: (evento) => { console.log('Un elemento cambio de lugar') }, */
});

const listaTareasCompletadas = Sortable.create(tareasCompletadas, {
	group: {
		name: "lista-tareas",
		pull: "clone",
		put: true
	},
	animation: 150,
	easing: "cubic-bezier(0.895, 0.03, 0.685, 0.22)",
	handle: ".fas",
	filter: ".titulo",
	// ghostClass: "active",
	chosenClass: "active",
	sort:false,
	//dragClass: "invisible"
	/**onEnd: (evt) => {
		var itemEl = evt.item;  // dragged HTMLElement
		console.log(itemEl);    // muestra el objeto
		var id = itemEl.getAttribute("id");
		console.log("id:" + id);
		alert("id:" + id);
		let modulos = document.getElementById(id);
		modulos.style.color="red";

	},*/

	// Called when creating a clone of element
	onClone: function (/**Event*/evt) {
		var origEl = evt.item;
		var cloneEl = evt.clone;
		//console.log(origEl);
		//console.log(cloneEl);
		cloneEl.style.color = "green";
		cloneEl.style.opacity = "0.5";
		cloneEl.classList.toggle('titulo');
		let id = origEl.getAttribute("id");
		cloneEl.setAttribute("clonado",id); //"Marca" elemento clonado con el atributo "clonado" y el id
		/*var id = origEl.getAttribute("id");

		let modulos = document.getElementById(id);
		modulos.style.color = "green";*/

	},
	onAdd: (evt) => {//cuando "devuelvo un módulo a la lista"
		elementoAdd = evt.item;
		let id = elementoAdd.getAttribute("id");
		let elementoClonado=document.querySelector("div[clonado='"+id+ "'");
		/*elementoClonado.style.color="black";
		elementoClonado.style.opacity = 1;
		elementoClonado.classList.toggle('titulo');
		elementoClonado.removeAttribute('clonado');*/
		let nombreProfe = elementoClonado.getAttribute('profe');
		let profeAsociado= document.querySelector("div[nombre='" + nombreProfe + "'");
		let horasprofeAsociado = parseInt(profeAsociado.getAttribute("horas"));
		let horasModulo = parseInt(elementoClonado.getAttribute("horas"));
		horasprofeAsociado = horasprofeAsociado - horasModulo;
		profeAsociado.setAttribute("horas", horasprofeAsociado);
		pintaProfe(profeAsociado);

		reiniciaModulo(elementoClonado);
		elementoAdd.parentNode.removeChild(elementoAdd); //se elimina el elemento añadido
		console.log('Se agrego un elemento a la lista') },
	/*onChoose: (evento) => {
		console.log('Se ha seleccionado un elemento')
	},
	onUnchoose: (evento) => { console.log('Se ha deseleccionado un elemento') },
	onStart: (evento) => { console.log('Se inicio el drag and drop') },
	onEnd: (evento) => { console.log('On End') },


	
	onRemove: (evento) => { console.log('Se elimino un elemento a la lista') },
	onUpdate: (evento) => { console.log('Se actualizo la lista') },
	onFilter: (evento) => { console.log('Se intento mover un elemento filtrado') },
	onMove: (evento) => { console.log('Se movio un elemento') },
	onChange: (evento) => { console.log('Un elemento cambio de lugar') },*/

});

const btnToggle = document.getElementById('toggle');
btnToggle.addEventListener('click', () => {
	const estado = listaTareas.option('disabled');
	listaTareas.option('disabled', !estado);

	if(estado){
		btnToggle.textContent = "Bloquear";
	} else {
		btnToggle.textContent = "Desbloquear";
	}
});